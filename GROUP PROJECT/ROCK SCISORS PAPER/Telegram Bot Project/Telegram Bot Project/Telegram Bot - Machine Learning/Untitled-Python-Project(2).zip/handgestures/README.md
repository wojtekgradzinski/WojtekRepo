# Small edit from from https://github.com/Let-s-get-visual/HandGesturesDataCollector

In this version, only the skeleton of the hand is retrieved in a picture of shape (32,32) in order to make it to work also with small models.

To capture the data run 

```python data_capture.py```

See Notebook to interact with single images.


